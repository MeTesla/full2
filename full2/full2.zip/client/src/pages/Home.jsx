import React , {useContext} from 'react'
import { AuthContext } from '../contexts/Auth'
function Home() {
  
  return (
    <div>
      <h1>Home</h1>
      
    </div>
  )
}

export default Home
