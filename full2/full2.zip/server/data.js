const data=[
    {"question": "Qui est-ce ?",
        "reponse":"C'est moi !"
    },
        {"question": "Pourquoi tu est venu ?",
        "reponse":"Pour te voir"
    }
]
module.exports = data